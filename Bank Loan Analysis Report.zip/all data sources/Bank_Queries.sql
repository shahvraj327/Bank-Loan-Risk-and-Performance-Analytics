SELECT * FROM BANK_LOAN_data

SELECT count(id) as Total_Loan_Applications from bank_loan_data

--Month to date loan applicants.
SELECT count(id) as MTD_Total_Loan_Applications from bank_loan_data
where MONTH(issue_date) = 12 and YEAR(issue_date)= 2021;


--previous month to date loan applicants.
SELECT COUNT(id) AS PMTD_Total_Applications FROM bank_loan_data
WHERE MONTH(issue_date) = 11


--total funded amount
select sum(loan_amount)as total_funded_amount from bank_loan_data

--MTD(month-to-date) funded amount for december.
SELECT SUM(loan_amount) AS MTD_Total_Funded_Amount FROM bank_loan_data
WHERE MONTH(issue_date) = 12


--PMTD for november.
SELECT SUM(loan_amount) AS Total_Funded_Amount FROM bank_loan_data
WHERE MONTH(issue_date) = 11



--Total Amount Received
SELECT SUM(total_payment) AS Total_Amount_Collected FROM bank_loan_data


--MTD Total Amount Received
SELECT SUM(total_payment) AS MTD_Total_Amount_Collected FROM bank_loan_data
WHERE MONTH(issue_date) = 12 AND YEAR(issue_date) =2021


--PMTD Total Amount Received
SELECT SUM(total_payment) AS MTD_Total_Amount_Collected FROM bank_loan_data
WHERE MONTH(issue_date) = 11 AND YEAR(issue_date) =2021




--Average Interest Rate
SELECT ROUND(AVG(int_rate), 4)*100 AS Avg_Int_Rate FROM bank_loan_data


--MTD Average Interest Rate
SELECT ROUND(AVG(int_rate), 4)*100 AS Avg_Int_Rate FROM bank_loan_data
where month(issue_date) =12 and year(issue_date) = 2021


--PMTD Average Interest Rate
SELECT ROUND(AVG(int_rate), 4)*100 AS Avg_Int_Rate FROM bank_loan_data
where month(issue_date) =11 and year(issue_date) = 2021




--Avg DTI (after checking the customer 'dti' a loan is offerd/issued to customer!!)
select round(avg(dti),4) * 100 from bank_loan_data


--MTD Avg DTI
select round(avg(dti),4) * 100 from bank_loan_data
WHERE MONTH(issue_date) = 12


--PMTD Avg DTI(DebtToIncome : value not suggested tooLOW/tooHIGH)
select round(avg(dti),4) * 100 from bank_loan_data
WHERE MONTH(issue_date) = 11




--Good Loan Issued Percentage(%)
select loan_status from bank_loan_data

SELECT
	(COUNT(case when loan_status = 'Fully Paid' OR loan_status = 'Current' then id END)*100)
	/
	count(id) AS good_loan_Percentage
From bank_loan_data;

--Good Loan Applications
SELECT
	(COUNT(case when loan_status = 'Fully Paid' OR loan_status = 'Current' then id END))
	AS GoodLoanApplications
From bank_loan_data;

--Good Loan Funded Amount
SELECT
	(sum(case when loan_status = 'Fully Paid' OR loan_status = 'Current' then loan_amount END))
	AS GoodLoanFundedAmount
From bank_loan_data;


--Good Loan Amount received 
SELECT
	(sum(case when loan_status = 'Fully Paid' OR loan_status = 'Current' then total_payment END))
	AS GoodLoanAmountReceived 
From bank_loan_data;



--BAD LOAN PERCENTAGE
SELECT 
	(count(case when loan_status = 'Charged Off' then id end))*100.0
	/
	count(id) AS BAD_LOAN_PERCENTAGE
From bank_loan_data;

--	Bad Loan Applications
SELECT COUNT(id) AS Bad_Loan_Applications FROM bank_loan_data
WHERE loan_status = 'Charged Off'

--Bad Loan Funded Amount
SELECT SUM(loan_amount) AS Bad_Loan_Funded_amount FROM bank_loan_data
WHERE loan_status = 'Charged Off'

--Bad Loan Amount Received
SELECT SUM(total_payment) AS Bad_Loan_amount_received FROM bank_loan_data
WHERE loan_status = 'Charged Off'




--	LOAN STATUS
	SELECT
        loan_status,
        COUNT(id) AS LoanCount,
        SUM(total_payment) AS Total_Amount_Received,
        SUM(loan_amount) AS Total_Funded_Amount,
        AVG(int_rate * 100) AS Interest_Rate,
        AVG(dti * 100) AS DTI
    FROM
        bank_loan_data
    GROUP BY
        loan_status 



-- (B) BANK LOAN REPORT | OVERVIEW
SELECT 
	MONTH(issue_date) AS Month_Munber, 
	DATENAME(MONTH, issue_date) AS Month_name, 
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY MONTH(issue_date), DATENAME(MONTH, issue_date)
ORDER BY MONTH(issue_date)




--	STATE
SELECT 
	address_state AS State, 
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY address_state
ORDER BY address_state



--TERM
SELECT 
	term ,
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY term
ORDER BY term DESC




-- EMPLOYEE LENGTH
SELECT 
	emp_length AS Employee_Length, 
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY emp_length
ORDER BY COUNT(id) DESC






-- PURPOSE
SELECT 
	purpose AS PURPOSE, 
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY purpose
ORDER BY SUM(loan_amount) DESC






-- HOME OWNERSHIP
SELECT 
	home_ownership AS Home_Ownership, 
	COUNT(id) AS Total_Loan_Applications,
	SUM(loan_amount) AS Total_Funded_Amount,
	SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
WHERE address_state = 'NY' AND grade = 'A'
GROUP BY home_ownership
ORDER BY COUNT(id) DESC



